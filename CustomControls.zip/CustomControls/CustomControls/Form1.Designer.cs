﻿namespace CustomControls
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbDarkTheme = new CustomControls.RJControls.RJToggleButton();
            this.rjToggleButton2 = new CustomControls.RJControls.RJToggleButton();
            this.rjToggleButton1 = new CustomControls.RJControls.RJToggleButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(223, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Dark Theme ";
            // 
            // tbDarkTheme
            // 
            this.tbDarkTheme.Checked = true;
            this.tbDarkTheme.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tbDarkTheme.Location = new System.Drawing.Point(223, 67);
            this.tbDarkTheme.MinimumSize = new System.Drawing.Size(45, 22);
            this.tbDarkTheme.Name = "tbDarkTheme";
            this.tbDarkTheme.OffBackColor = System.Drawing.Color.Turquoise;
            this.tbDarkTheme.OffToggleColor = System.Drawing.Color.SpringGreen;
            this.tbDarkTheme.OnBackColor = System.Drawing.Color.Yellow;
            this.tbDarkTheme.OnToggleColor = System.Drawing.Color.Linen;
            this.tbDarkTheme.Size = new System.Drawing.Size(104, 24);
            this.tbDarkTheme.TabIndex = 2;
            this.tbDarkTheme.UseVisualStyleBackColor = true;
            // 
            // rjToggleButton2
            // 
            this.rjToggleButton2.AutoSize = true;
            this.rjToggleButton2.Checked = true;
            this.rjToggleButton2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rjToggleButton2.Location = new System.Drawing.Point(113, 102);
            this.rjToggleButton2.MinimumSize = new System.Drawing.Size(45, 22);
            this.rjToggleButton2.Name = "rjToggleButton2";
            this.rjToggleButton2.OffBackColor = System.Drawing.Color.Gray;
            this.rjToggleButton2.OffToggleColor = System.Drawing.Color.LightCoral;
            this.rjToggleButton2.OnBackColor = System.Drawing.Color.Indigo;
            this.rjToggleButton2.OnToggleColor = System.Drawing.Color.SpringGreen;
            this.rjToggleButton2.Size = new System.Drawing.Size(45, 22);
            this.rjToggleButton2.SolidStyle = false;
            this.rjToggleButton2.TabIndex = 1;
            this.rjToggleButton2.UseVisualStyleBackColor = true;
            // 
            // rjToggleButton1
            // 
            this.rjToggleButton1.AutoSize = true;
            this.rjToggleButton1.Checked = true;
            this.rjToggleButton1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.rjToggleButton1.Location = new System.Drawing.Point(113, 34);
            this.rjToggleButton1.MinimumSize = new System.Drawing.Size(45, 22);
            this.rjToggleButton1.Name = "rjToggleButton1";
            this.rjToggleButton1.OffBackColor = System.Drawing.Color.Gray;
            this.rjToggleButton1.OffToggleColor = System.Drawing.Color.IndianRed;
            this.rjToggleButton1.OnBackColor = System.Drawing.Color.MediumSeaGreen;
            this.rjToggleButton1.OnToggleColor = System.Drawing.Color.DarkSlateGray;
            this.rjToggleButton1.Size = new System.Drawing.Size(45, 22);
            this.rjToggleButton1.TabIndex = 0;
            this.rjToggleButton1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbDarkTheme);
            this.Controls.Add(this.rjToggleButton2);
            this.Controls.Add(this.rjToggleButton1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RJControls.RJToggleButton rjToggleButton1;
        private RJControls.RJToggleButton rjToggleButton2;
        private RJControls.RJToggleButton tbDarkTheme;
        private System.Windows.Forms.Label label1;
    }
}

